﻿using System;

namespace Infra
{
    public class Class1
    {
    }
}
