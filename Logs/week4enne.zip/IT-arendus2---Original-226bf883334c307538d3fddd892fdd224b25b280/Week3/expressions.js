//See on halb näide:
a;

// Expressioni tüübid
// ====================

// 1. Muutuja deklareerimine
let a;

// 2. Väärtuse omistamine
//a = 4;

// Tee operatsioon ja väljasta üks väärtus
// b + c

let b = 3;
let c = 2;
// Siin on kolm expressioni
let a = b + c;

// 1. let a muutuja deklareerimine
// 2. tee b + c
// 3. result omistatakse a'le.