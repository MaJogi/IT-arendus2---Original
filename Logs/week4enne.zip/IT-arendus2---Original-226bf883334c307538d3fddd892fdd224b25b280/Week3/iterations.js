// for (i = 0; i < 10; i++) {
//     console.log(i);
// }

let a = [4, 8, 15, 16, 23, 42];
// for (i =0; i < a.length; i++) {
//     console.log(a[i]);
// }

// for (let i = 0; i < a.length; i++) {
//     const element = a[i];
//     console.log(element);
// }
let x = 1;
while (x < 10) {
    console.log(x++); // esiteks, prindi välja x ja seejärel lisa +1 talle.

    if (x == 7) break; //lühikene if'i formaat.

    if (x == 7) {
        break;
    }
}

