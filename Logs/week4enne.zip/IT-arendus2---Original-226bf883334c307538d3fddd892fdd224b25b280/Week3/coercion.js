let a = 7;
let b = '6';
b = parseInt(b, 10); //10 kümnendsüsteemi konvertimisel.
let c = a + b; //Liidan kokku numbri ja sõne, et saada sõne.
console.log('Answer: ' + c);

let d = parseInt('bob', 10);
let e = isNan(d);
console.log(d);
console.log(e);