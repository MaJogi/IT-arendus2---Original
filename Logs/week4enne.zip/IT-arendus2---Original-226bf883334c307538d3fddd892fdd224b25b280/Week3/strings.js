let first = "Quote 1";
let second = "Quote 2";
let third = "4,8,12";

// You can even call methods on string literals
// console.log("do whatever it takes to become succesful!".toUpperCase());

// let mySplit = third.split(",");
// console.log(mySplit);

// let mySlice = first.slice(13, 18);
// console.log(mySlice);



// let mySubstr = first.substr(13, 5);

// let myEndsWith = second.endsWith("try.");

// let myStartsWith = second.startsWith("Do");

// let myInclude = second.includes("there");

let myRepeat = "Ha!".repeat(3);

let myTrim = "    bloated  ";
