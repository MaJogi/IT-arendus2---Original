let today = new Date();


let bob = new Date("December 7, 1969 07:01:23");
// let bob = new Date("1969-12-07T07:01:23");
// let bob = new Date(1969, 11, 6);
// let bob = new Date(1969, 11, 6, 7, 1, 23);

var elapsedTime = today - bob;

// console.log(elapsedTime / 1000 / 60 / 60 / 24 /365.25)
// console.log(bob.getDate()); // Monday = 1, Sunday = 7
console.log(bob.getTime());

getMonth();
getDay();

getHours();
GetMinutes();
getSeconds();
getMilliseconds();