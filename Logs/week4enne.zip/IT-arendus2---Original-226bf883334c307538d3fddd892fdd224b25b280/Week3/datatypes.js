let x = 7;
console.log(typeof x);

let y = true;
console.log(typeof y);

let z = 'hello world'
console.log(typeof z);

let a;
console.log(a);
console.log(typeof a);

