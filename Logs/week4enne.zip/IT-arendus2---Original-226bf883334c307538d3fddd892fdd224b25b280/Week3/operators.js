// Categories of Operators

// Assigment =
// Arithmetic + - * / %
var m = 10 % 3; //Get a remainder
console.log(m);
// Increment / Decrement ++ --
var a = 1;
a++;
console.log(a++); // incremintation is done after printing variable out.
//console.log(++a) to make it work the way it's ment to.
console.log(a);

// String '' + 

// Precedence 
var b = 1 + 2 * 3; //order of operations!

// Logcal and: && or: ||

// Code block operators { }

// Array element access operators []

