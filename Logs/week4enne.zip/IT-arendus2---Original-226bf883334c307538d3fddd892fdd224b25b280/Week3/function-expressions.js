// setTimeout(function () { 
//     console.log('I waited 2 seconds')
// }, 2000); //millisekundite arv


// let counter = 0;
// function timeout(){
//     setTimeout(function () {
//         console.log('hi' + counter++);
//         timeout();
//     },2000)
// }
// timeout();

(function () {
    console.log('hi');
})();