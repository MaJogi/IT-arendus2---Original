﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            //Tähtis
            //1. Array'd on fikseeritud suurusega.

            int[] numbers = new int[5];
            numbers[1] = 2;

            //Kasulikud meetodid: numbers.Lenght
            //Deklareerin array elemendind luues array.
            int[] numbers2 = new int[] {4, 8, 15, 16, 23, 42}; 
            string[] names = new string[] {"Marko", "Lisete", "Tiit", "Teet"};
        }
    }
}
