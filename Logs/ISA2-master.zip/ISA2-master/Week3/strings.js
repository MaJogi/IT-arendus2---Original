let first = 'Knowlege is power';
let second = 'Do or do not. There is no try.';
let third = '1,2,3,4,5,6';

// console.log('bob'.toUpperCase());

/* let mySplit = third.split(',');
console.log(mySplit); */

/* let mySlice = first.slice(3, 8);
console.log(mySlice); */

/* let mySubster = first.substr(3,8);
console.log(mySubster); */

/* let myEndsWith = second.endsWith('try.');
console.log(myEndsWith);

let myStartsWith = second.startsWith('Do');
console.log(myStartsWith);

let myInclude = second.includes('There');
console.log(myInclude);
*/

/* let myReapet = 'Ha!'.repeat(3);
console.log(myReapet); */

let myTrim = '   bloated   ';
console.log(myTrim.length);
console.log(myTrim.trim().length);