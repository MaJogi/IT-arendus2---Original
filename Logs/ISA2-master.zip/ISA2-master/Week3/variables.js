//let x;
//console.log(x);
//x = 7;
let x = 7;
// X = 8;
x = 6;
x = 5;
x = 4;
// let x = 8;
let y = 3;
let z = x + y;
console.log('Answer: ' + z);

// let let = 8;
let firstNumber = 7;
let secondNumber = 3;
let firstName = 'Bob';
let firstZipCode = '75082';

let secondZipCode = '60459';