// Categories of Operators 

// Assigment = 
// Arithemetic + - * / %
//var m = 10 % 3;
//console.log(m);

// Increment / Decrement ++ --
/*
var a =1;
a++;
//console.log(a++);
console.log(++a);
console.log(a);
*/

//String '' +

//Precedence
//var b = (1 + 2) * 3;
//console.log(b);

//Function invocation operators 
//console.log('')

//Logical and: && or:||

//Member accessor operator
//console.log()

//Code block operators {}

//Array element access operators []