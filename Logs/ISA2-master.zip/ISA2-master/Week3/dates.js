let today = new Date();

let bob = new Date('December 7, 1969 07:01:23');
/* let bob = new Data('1969-12-07T07:01:23');
let bob = new Data(1969, 11, 6);
let bob = new Data(1969, 11, 6, 7, 1, 23); */

/* var elapsedTime = today - bob;
console.log(elapsedTime); */

console.log(bob.getDate()); //Monday = 1, Sunday = 7
console.log(bob.getTime());