let x = 7;
console.log(typeof x);

let y = true; //true or false
console.log(typeof y);

let z = 'hello world'; //single quotes 
console.log(typeof z);

let a;
console.log(a);
console.log(typeof a);

console.log('9');