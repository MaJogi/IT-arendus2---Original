// This is bad:
//a;

//Types of expressions
//=====================

// 1.Variable Declaration
//let a;

//2. Assign a value
//a = 4;

//Perform an evaluation that returns a single value
// b + c

let b = 3;
let c = 2;
//Three expressions in here .. can you find them ?
let a = b + c;

//1. let a... variable declaration
//2. perform an eval b + c
//3. result assigned to a 