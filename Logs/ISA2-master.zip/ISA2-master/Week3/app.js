// console.log('hi');

let x = 7;
let y = 3;
let z = x + y;
console.log('Answer: ' + z);